'''
The karmarker karp algorithm, run on both standard input
and prepartitioned input.
'''
import numpy as np
from utils import *

def kk_n():
    '''
    KK algorithm on normal data representation.
    '''
    pass

def kk_p():
    '''
    KK algorithm on prepartitioned data representation.
    '''
    pass

if __name__ == "__main__":
    # unit test the KK algorithm
    pass